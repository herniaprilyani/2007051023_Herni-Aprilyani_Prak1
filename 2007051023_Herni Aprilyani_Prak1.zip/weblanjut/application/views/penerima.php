<?php
echo "data yang diterima adalah ", $test;
?>